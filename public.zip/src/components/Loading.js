import React from 'react';
import './Loader.css'

const Loading = () => {
    return <div className="loader"></div>
}

export default Loading