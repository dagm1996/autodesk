const amplifyConfig = {
    auth: {
        userPoolId: "us-east-2_8i7Pe1Ejn",
        clientId: "486jdp55loudfoo165o9ple2ir",
    },
};

export default amplifyConfig